import Image from 'next/image';

// Placeholder components for layout sections
const TopBar = () => (
  <header className="amarax-top-bar h-16 flex items-center px-6 text-sm shadow-lg justify-between">
    {/* Amarax Central Logo and Branding */}
    <div className="flex items-center space-x-3">
      <Image src="/logos/amarax_icon.png" alt="Amarax Central Logo" width={36} height={36} className="rounded-md shadow-md" />
      <span className="font-semibold text-xl text-[rgb(var(--foreground-rgb))]">Amarax Central</span>
    </div>

    {/* Navigation Links - can be further refined with icons */}
    <nav className="flex items-center space-x-5">
      <a href="#" className="text-[rgb(var(--foreground-rgb))] hover:text-[rgb(var(--amarax-cyan-highlight))] transition-colors duration-200">Dashboard</a>
      <a href="#" className="text-[rgb(var(--foreground-rgb))] hover:text-[rgb(var(--amarax-cyan-highlight))] transition-colors duration-200">Agents</a>
      <a href="#" className="text-[rgb(var(--foreground-rgb))] hover:text-[rgb(var(--amarax-cyan-highlight))] transition-colors duration-200">Marketplace</a>
      <a href="#" className="text-[rgb(var(--foreground-rgb))] hover:text-[rgb(var(--amarax-cyan-highlight))] transition-colors duration-200">FlowBuilder</a>
      <a href="#" className="text-[rgb(var(--foreground-rgb))] hover:text-[rgb(var(--amarax-cyan-highlight))] transition-colors duration-200">Settings</a>
    </nav>

    {/* User Profile / Login Button */}
    <div className="flex items-center">
        {/* User avatar/icon - could be a mascot variant or user-uploaded image */}
        {/* <Image src="/mascots/mascot_style_1.png" alt="User Avatar" width={32} height={32} className="rounded-full mascot-avatar mr-2" /> */}
        <button className="btn-primary text-xs font-medium">
            Login
        </button>
        {/* <span className="text-sm text-[rgb(var(--foreground-rgb))] ml-3">User Name</span> */}
    </div>
  </header>
);

const LeftSidebar = () => (
  // Icons could be stylized to match mascot aesthetics or even be simplified mascot representations.
  <aside className="amarax-sidebar-left w-16 flex flex-col items-center py-5 space-y-5 shadow-lg">
    {/* Example of using a mascot as an icon - replace with actual icons or more abstract mascot representations */}
    <div title="Dashboard" className="w-10 h-10 rounded-lg flex items-center justify-center text-[rgb(var(--foreground-rgb))] hover:bg-[rgb(var(--amarax-purple-primary))] hover:text-white cursor-pointer transition-all duration-200 animate-fadeIn">
      {/* <Image src="/mascots/dashboard_mascot.png" alt="Dashboard" width={24} height={24} /> */}
      <span className="text-xl">D</span>
    </div>
    <div title="Chat" className="w-10 h-10 rounded-lg flex items-center justify-center text-[rgb(var(--foreground-rgb))] hover:bg-[rgb(var(--amarax-purple-primary))] hover:text-white cursor-pointer transition-all duration-200 animate-fadeIn" style={{animationDelay: '0.1s'}}>
      <span className="text-xl">C</span>
    </div>
    <div title="My Agents" className="w-10 h-10 rounded-lg flex items-center justify-center text-[rgb(var(--foreground-rgb))] hover:bg-[rgb(var(--amarax-purple-primary))] hover:text-white cursor-pointer transition-all duration-200 animate-fadeIn" style={{animationDelay: '0.2s'}}>
      {/* Potential place for a generic agent mascot icon */}
      {/* <Image src="/mascots/agent_icon_generic.png" alt="My Agents" width={24} height={24} /> */}
      <span className="text-xl">Ag</span>
    </div>
    <div title="Flow Builder" className="w-10 h-10 rounded-lg flex items-center justify-center text-[rgb(var(--foreground-rgb))] hover:bg-[rgb(var(--amarax-purple-primary))] hover:text-white cursor-pointer transition-all duration-200 animate-fadeIn" style={{animationDelay: '0.3s'}}>
      <span className="text-xl">Fl</span>
    </div>
    <div title="Agent Marketplace" className="w-10 h-10 rounded-lg flex items-center justify-center text-[rgb(var(--foreground-rgb))] hover:bg-[rgb(var(--amarax-purple-primary))] hover:text-white cursor-pointer transition-all duration-200 animate-fadeIn" style={{animationDelay: '0.4s'}}>
      <span className="text-xl">M</span>
    </div>
    <div title="Settings" className="mt-auto w-10 h-10 rounded-lg flex items-center justify-center text-[rgb(var(--foreground-rgb))] hover:bg-[rgb(var(--amarax-purple-primary))] hover:text-white cursor-pointer transition-all duration-200 animate-fadeIn" style={{animationDelay: '0.5s'}}>
      <span className="text-xl">S</span>
    </div>
  </aside>
);

const RightSidebar = () => (
  <aside className="amarax-sidebar-right w-72 p-5 shadow-lg">
    <h3 className="font-semibold text-[rgb(var(--foreground-rgb))] mb-4 text-lg border-b border-[rgb(var(--border-rgb))] pb-2">Contextual Details</h3>
    <div className="text-[rgb(var(--foreground-rgb))] text-opacity-80 text-sm space-y-4">
      <p>Select an agent or item to see more information here.</p>
      {/* Example of displaying a mascot for a selected agent */}
      <div className="animate-fadeIn bg-[rgb(var(--panel-background-rgb))] p-4 rounded-lg shadow-md">
        <Image src="/mascots/mascot_style_1.png" alt="Selected Agent Mascot" width={80} height={80} className="mascot-image mx-auto mb-3 rounded-lg" />
        <p className="text-center font-semibold">Agent Alpha</p>
        <p className="text-xs text-center text-opacity-70">A friendly assistant bot.</p>
      </div>
      <div className="animate-pulse-engage w-full h-24 bg-[rgb(var(--panel-background-rgb))] rounded-md flex items-center justify-center mt-4">
        <p className="text-xs text-[rgb(var(--foreground-rgb))] text-opacity-60">Other Dynamic Content</p>
      </div>
    </div>
  </aside>
);

const StatusBar = () => (
  <footer className="amarax-status-bar h-8 flex items-center px-5 text-xs shadow-inner_top justify-between">
    <div className="flex items-center space-x-2">
        <div className="w-3 h-3 bg-[rgb(var(--amarax-cyan-highlight))] rounded-full animate-pulse-engage"></div>
        <p className="text-[rgb(var(--foreground-rgb))] text-opacity-70">Status: Online</p>
        <p className="text-[rgb(var(--foreground-rgb))] text-opacity-70">|</p>
        <p className="text-[rgb(var(--foreground-rgb))] text-opacity-70">Version 1.0.0</p>
    </div>
    <div className="text-[rgb(var(--foreground-rgb))] text-opacity-60">Amarax Productions™️©️</div>
  </footer>
);

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`flex flex-col h-screen text-[rgb(var(--foreground-rgb))]`}>
        <TopBar />
        <div className="flex flex-1 overflow-hidden">
          <LeftSidebar />
          <main className="amarax-main-content flex-1 overflow-y-auto p-6 bg-[rgba(var(--panel-background-rgb),0.3)]">
            {children}
          </main>
          <RightSidebar />
        </div>
        <StatusBar />
      </body>
    </html>
  );
}

