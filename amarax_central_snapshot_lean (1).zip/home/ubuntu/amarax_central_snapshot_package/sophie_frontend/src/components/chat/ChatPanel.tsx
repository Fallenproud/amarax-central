"use client";

import React, { useState, useEffect, useRef } from 'react';
import Image from 'next/image'; // Import Image component

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'agent';
  timestamp: Date;
  agentName?: string; // Optional: Name of the agent sending the message
  avatarUrl?: string; // Optional: path to agent avatar (mascot)
}

// Example: Assume we have a way to know the current active agent's details
interface ActiveAgent {
  id: string;
  name: string;
  mascot_avatar_url: string;
}

const ChatPanel = ({ activeAgent }: { activeAgent?: ActiveAgent }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<null | HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Use active agent's mascot or a default
  const defaultAgentAvatar = "/mascots/mascot_style_1.png"; // A default Amarax mascot
  const currentAgentName = activeAgent?.name || "Amarax Agent";
  const currentAgentAvatar = activeAgent?.mascot_avatar_url || defaultAgentAvatar;

  const handleSendMessage = () => {
    if (inputValue.trim() === '') return;

    const userMessage: Message = {
      id: Date.now().toString() + '-user',
      text: inputValue,
      sender: 'user',
      timestamp: new Date(),
    };
    setMessages(prevMessages => [...prevMessages, userMessage]);

    // Simulate agent response
    setTimeout(() => {
      const agentResponse: Message = {
        id: Date.now().toString() + '-agent',
        text: `${currentAgentName} received: "${inputValue}" (This is a simulated response)`,
        sender: 'agent',
        timestamp: new Date(),
        agentName: currentAgentName,
        avatarUrl: currentAgentAvatar, // Use the current agent's avatar
      };
      setMessages(prevMessages => [...prevMessages, agentResponse]);
    }, 1000);

    setInputValue('');
  };

  return (
    <div className="flex flex-col h-full bg-[rgba(var(--panel-background-rgb),0.7)] shadow-xl rounded-lg overflow-hidden backdrop-blur-sm">
      {/* Chat Header */}
      <div className="p-3 bg-[rgba(var(--panel-background-rgb),0.9)] border-b border-[rgb(var(--border-rgb))] flex items-center space-x-2">
        {activeAgent && activeAgent.mascot_avatar_url ? (
            <Image src={activeAgent.mascot_avatar_url} alt={`${activeAgent.name} Avatar`} width={32} height={32} className="rounded-full mascot-image" />
        ) : (
            <Image src={defaultAgentAvatar} alt="Default Agent Avatar" width={32} height={32} className="rounded-full mascot-image" />
        )}
        <h2 className="text-md font-semibold text-[rgb(var(--foreground-rgb))]">{currentAgentName}</h2>
      </div>

      {/* Messages Area */}
      <div className="flex-1 p-4 space-y-3 overflow-y-auto scrollbar-thin scrollbar-thumb-[rgb(var(--border-rgb))] scrollbar-track-[rgba(var(--panel-background-rgb),0.5)]">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-end space-x-2 ${msg.sender === 'user' ? 'justify-end' : ''}`}
          >
            {msg.sender === 'agent' && (
              <Image 
                src={msg.avatarUrl || defaultAgentAvatar} 
                alt={msg.agentName || "Agent Avatar"}
                width={32} 
                height={32} 
                className="rounded-full mascot-image bg-[rgb(var(--input-background-rgb))]" // Added bg for potential transparency in mascots
              />
            )}
            <div
              className={`max-w-xs lg:max-w-md px-3 py-2 rounded-lg shadow-md ${ 
                msg.sender === 'user'
                  ? 'bg-[rgb(var(--amarax-blue-accent))] text-white rounded-br-none'
                  : 'bg-[rgb(var(--input-background-rgb))] text-[rgb(var(--foreground-rgb))] rounded-bl-none'
              }`}
            >
              <p className="text-sm">{msg.text}</p>
              <p className="text-xs text-[rgba(var(--foreground-rgb),0.6)] mt-1 text-right">
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
            {msg.sender === 'user' && (
                <div className="w-8 h-8 rounded-full bg-[rgb(var(--amarax-purple-primary))] flex items-center justify-center text-white font-bold text-sm shadow-md">U</div>
            )}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-3 bg-[rgba(var(--panel-background-rgb),0.9)] border-t border-[rgb(var(--border-rgb))]">
        <div className="flex items-center space-x-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder={`Message ${currentAgentName}...`}
            className="flex-1 p-2 bg-[rgb(var(--input-background-rgb))] border border-[rgb(var(--border-rgb))] rounded-lg text-[rgb(var(--foreground-rgb))] placeholder-gray-500 focus:ring-[rgb(var(--amarax-cyan-highlight))] focus:border-[rgb(var(--amarax-cyan-highlight))] outline-none"
          />
          <button
            onClick={handleSendMessage}
            className="px-4 py-2 bg-[rgb(var(--amarax-blue-accent))] hover:bg-opacity-80 text-white font-semibold rounded-lg focus:outline-none focus:ring-2 focus:ring-[rgb(var(--amarax-blue-accent))] focus:ring-opacity-50 transition-colors duration-150"
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatPanel;

