"use client";

import React, { useState } from 'react';
import Image from 'next/image'; // Import Image component

// Mock data structure for data sources - replace with actual types
interface DataSource {
  id: string;
  name: string;
  type: 'file' | 'url' | 'text';
  content?: string; // for text type
  file?: File; // for file type
  url?: string; // for url type
}

// Predefined mascot options
const mascotOptions = [
  { name: 'Mascot Style 1 (Purple)', url: '/mascots/mascot_style_1.png' },
  { name: 'Mascot Style 2 (Blue/Orange)', url: '/mascots/mascot_style_2.png' },
  // Add more predefined mascot URLs here as they are added to /public/mascots
  { name: 'No Mascot', url: '' },
];

const RagAgentCreator = () => {
  const [agentName, setAgentName] = useState('');
  const [agentDescription, setAgentDescription] = useState('');
  const [selectedMascotUrl, setSelectedMascotUrl] = useState(mascotOptions[0].url); // Default to first mascot
  const [dataSources, setDataSources] = useState<DataSource[]>([]);
  const [newDataSourceType, setNewDataSourceType] = useState<
    'file' | 'url' | 'text'
  >('text');
  const [newDataSourceContent, setNewDataSourceContent] = useState('');
  const [newDataSourceFile, setNewDataSourceFile] = useState<File | null>(null);
  const [newDataSourceUrl, setNewDataSourceUrl] = useState('');

  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAddDataSource = () => {
    let newSource: DataSource | null = null;
    if (newDataSourceType === 'text' && newDataSourceContent.trim() !== '') {
      newSource = {
        id: Date.now().toString(),
        name: `Text Snippet ${dataSources.length + 1}`,
        type: 'text',
        content: newDataSourceContent,
      };
      setNewDataSourceContent('');
    } else if (newDataSourceType === 'file' && newDataSourceFile) {
      newSource = {
        id: Date.now().toString(),
        name: newDataSourceFile.name,
        type: 'file',
        file: newDataSourceFile,
      };
      setNewDataSourceFile(null);
      const fileInput = document.getElementById(
        'dataSourceFile'
      ) as HTMLInputElement;
      if (fileInput) fileInput.value = '';
    } else if (newDataSourceType === 'url' && newDataSourceUrl.trim() !== '') {
      try {
        const url = new URL(newDataSourceUrl.trim()); // Basic URL validation
        newSource = {
          id: Date.now().toString(),
          name: url.hostname,
          type: 'url',
          url: url.toString(),
        };
        setNewDataSourceUrl('');
      } catch (_err) {
        setError('Invalid URL format.');
        return;
      }
    }

    if (newSource) {
      setDataSources([...dataSources, newSource]);
      setError('');
    } else {
      setError('Please provide content for the selected data source type.');
    }
  };

  const handleRemoveDataSource = (id: string) => {
    setDataSources(dataSources.filter((ds) => ds.id !== id));
  };

  const handleSubmitAgent = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    if (!agentName.trim()) {
      setError('Agent name is required.');
      return;
    }
    if (dataSources.length === 0) {
      setError('At least one data source is required for the RAG agent.');
      return;
    }
    setLoading(true);

    // TODO: Replace with actual API call to backend /api/v1/rag_agents (POST)
    // This would involve preparing FormData if files are included.
    // For now, we simulate and log.
    const agentData = {
      agent_name: agentName,
      description: agentDescription,
      knowledge_base_name: `${agentName}_kb`, // Example KB naming
      mascot_avatar_url: selectedMascotUrl,
      // dataSources would be handled differently, likely uploaded separately or processed by backend
    };

    try {
      console.log('Creating RAG Agent with data:', agentData);
      // const token = localStorage.getItem('jwt_token'); // Assuming JWT is stored
      // const response = await fetch('/api/v1/rag_agents', {
      //   method: 'POST',
      //   headers: {
      //     'Content-Type': 'application/json',
      //     'Authorization': `Bearer ${token}`
      //   },
      //   body: JSON.stringify(agentData),
      // });

      // if (response.ok) {
      //   const result = await response.json();
      //   setSuccess(`RAG Agent "${agentName}" created successfully! Mascot: ${result.mascot_avatar_url}`);
      //   setAgentName('');
      //   setAgentDescription('');
      //   setSelectedMascotUrl(mascotOptions[0].url);
      //   setDataSources([]);
      // } else {
      //   const errorData = await response.json();
      //   setError(errorData.msg || 'Failed to create RAG agent.');
      // }
      await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate API delay
      setSuccess(
        `Simulated RAG Agent "${agentName}" creation with mascot ${selectedMascotUrl}. API not fully connected.`
      );
    } catch (err) {
      setError('An unexpected error occurred during agent creation.');
      console.error(err);
    }
    setLoading(false);
  };

  return (
    <div className="p-6 bg-[rgba(var(--panel-background-rgb),0.8)] rounded-lg shadow-xl max-w-2xl mx-auto my-8 backdrop-blur-sm">
      <h2 className="text-xl font-semibold text-[rgb(var(--foreground-rgb))] mb-6">Create New RAG Agent</h2>
      <form onSubmit={handleSubmitAgent} className="space-y-6">
        <div>
          <label htmlFor="agentName" className="block text-sm font-medium text-[rgb(var(--foreground-rgb))]">Agent Name</label>
          <input
            id="agentName"
            type="text"
            value={agentName}
            onChange={(e) => setAgentName(e.target.value)}
            required
            className="mt-1 block w-full px-3 py-2 bg-[rgb(var(--input-background-rgb))] border border-[rgb(var(--border-rgb))] rounded-md text-[rgb(var(--foreground-rgb))] placeholder-gray-500 focus:outline-none focus:ring-[rgb(var(--amarax-cyan-highlight))] focus:border-[rgb(var(--amarax-cyan-highlight))] sm:text-sm"
            placeholder="My Custom Support Agent"
          />
        </div>
        <div>
          <label htmlFor="agentDescription" className="block text-sm font-medium text-[rgb(var(--foreground-rgb))]">Agent Description (Optional)</label>
          <textarea
            id="agentDescription"
            value={agentDescription}
            onChange={(e) => setAgentDescription(e.target.value)}
            rows={3}
            className="mt-1 block w-full px-3 py-2 bg-[rgb(var(--input-background-rgb))] border border-[rgb(var(--border-rgb))] rounded-md text-[rgb(var(--foreground-rgb))] placeholder-gray-500 focus:outline-none focus:ring-[rgb(var(--amarax-cyan-highlight))] focus:border-[rgb(var(--amarax-cyan-highlight))] sm:text-sm"
            placeholder="Handles customer queries about product X..."
          />
        </div>

        <div>
          <label htmlFor="mascotAvatarUrl" className="block text-sm font-medium text-[rgb(var(--foreground-rgb))]">Agent Mascot Avatar</label>
          <select
            id="mascotAvatarUrl"
            value={selectedMascotUrl}
            onChange={(e) => setSelectedMascotUrl(e.target.value)}
            className="mt-1 block w-full px-3 py-2 bg-[rgb(var(--input-background-rgb))] border border-[rgb(var(--border-rgb))] rounded-md text-[rgb(var(--foreground-rgb))] focus:outline-none focus:ring-[rgb(var(--amarax-cyan-highlight))] focus:border-[rgb(var(--amarax-cyan-highlight))] sm:text-sm"
          >
            {mascotOptions.map(option => (
              <option key={option.url} value={option.url}>{option.name}</option>
            ))}
          </select>
          {selectedMascotUrl && (
            <div className="mt-2 p-2 bg-[rgb(var(--input-background-rgb))] rounded-md inline-block">
              <Image src={selectedMascotUrl} alt="Selected Mascot Preview" width={64} height={64} className="rounded-md mascot-image" />
            </div>
          )}
        </div>

        {/* Data Sources Section */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-[rgb(var(--foreground-rgb))]">Knowledge Sources</h3>
          {dataSources.map(ds => (
            <div key={ds.id} className="p-3 bg-[rgb(var(--input-background-rgb))] rounded-md flex justify-between items-center border border-[rgb(var(--border-rgb))]">
              <div>
                <p className="text-sm font-medium text-gray-200">{ds.name}</p>
                <p className="text-xs text-gray-400">Type: {ds.type} {ds.type === 'file' && ds.file ? `(${Math.round(ds.file.size / 1024)} KB)` : ''}</p>
              </div>
              <button 
                type="button"
                onClick={() => handleRemoveDataSource(ds.id)}
                className="text-red-400 hover:text-red-300 text-xs"
              >
                Remove
              </button>
            </div>
          ))}
          {dataSources.length === 0 && <p className="text-sm text-gray-400">No knowledge sources added yet.</p>}

          {/* Add New Data Source Form */}
          <div className="p-4 border border-dashed border-[rgb(var(--border-rgb))] rounded-md space-y-3">
            <label htmlFor="dataSourceType" className="block text-sm font-medium text-[rgb(var(--foreground-rgb))]">Add New Source:</label>
            <select 
              id="dataSourceType" 
              value={newDataSourceType} 
              onChange={(e) => setNewDataSourceType(e.target.value as 'file' | 'url' | 'text')}
              className="block w-full px-3 py-2 bg-[rgb(var(--input-background-rgb))] border border-[rgb(var(--border-rgb))] rounded-md text-[rgb(var(--foreground-rgb))] focus:outline-none focus:ring-[rgb(var(--amarax-cyan-highlight))] focus:border-[rgb(var(--amarax-cyan-highlight))] sm:text-sm"
            >
              <option value="text">Plain Text</option>
              <option value="file">Upload File (.txt, .md, .pdf)</option>
              <option value="url">Website URL</option>
            </select>

            {newDataSourceType === 'text' && (
              <textarea 
                value={newDataSourceContent} 
                onChange={(e) => setNewDataSourceContent(e.target.value)} 
                rows={4} 
                placeholder="Paste your text content here..."
                className="mt-1 block w-full px-3 py-2 bg-[rgb(var(--input-background-rgb))] border border-[rgb(var(--border-rgb))] rounded-md text-[rgb(var(--foreground-rgb))] placeholder-gray-500 focus:outline-none focus:ring-[rgb(var(--amarax-cyan-highlight))] focus:border-[rgb(var(--amarax-cyan-highlight))] sm:text-sm"
              />
            )}
            {newDataSourceType === 'file' && (
              <input 
                id="dataSourceFile"
                type="file" 
                onChange={(e) => setNewDataSourceFile(e.target.files ? e.target.files[0] : null)} 
                className="mt-1 block w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-[rgb(var(--amarax-purple-primary))] file:text-white hover:file:bg-opacity-80 cursor-pointer"
              />
            )}
            {newDataSourceType === 'url' && (
              <input 
                type="url" 
                value={newDataSourceUrl} 
                onChange={(e) => setNewDataSourceUrl(e.target.value)} 
                placeholder="https://example.com/knowledge_page"
                className="mt-1 block w-full px-3 py-2 bg-[rgb(var(--input-background-rgb))] border border-[rgb(var(--border-rgb))] rounded-md text-[rgb(var(--foreground-rgb))] placeholder-gray-500 focus:outline-none focus:ring-[rgb(var(--amarax-cyan-highlight))] focus:border-[rgb(var(--amarax-cyan-highlight))] sm:text-sm"
              />
            )}
            <button 
              type="button" 
              onClick={handleAddDataSource}
              className="px-3 py-1.5 text-xs bg-[rgb(var(--amarax-cyan-highlight))] hover:bg-opacity-80 text-white font-semibold rounded-md focus:outline-none"
            >
              Add Source
            </button>
          </div>
        </div>

        {error && <p className="text-sm text-red-400">{error}</p>}
        {success && <p className="text-sm text-green-400">{success}</p>}

        <div>
          <button
            type="submit"
            disabled={loading}
            className="w-full flex justify-center py-2.5 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[rgb(var(--amarax-blue-accent))] hover:bg-opacity-80 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-[rgb(var(--amarax-blue-accent))] disabled:opacity-50"
          >
            {loading ? (
                <div className="loading-spinner w-5 h-5"></div>
            ) : (
                'Create RAG Agent'
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default RagAgentCreator;

