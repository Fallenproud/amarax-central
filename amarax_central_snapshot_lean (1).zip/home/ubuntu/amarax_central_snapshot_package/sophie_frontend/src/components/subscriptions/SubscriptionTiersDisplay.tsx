"use client";

import React from 'react';

interface SubscriptionTier {
  id: string;
  name: string;
  price: string;
  features: string[];
  ctaText: string;
  isPopular?: boolean;
  themeColor?: string; // e.g., 'amarax-blue', 'amarax-purple', 'amarax-cyan'
}

// Mock data for subscription tiers - replace with actual data from backend or config
const tiers: SubscriptionTier[] = [
  {
    id: 'free',
    name: 'Explorer (Free)',
    price: '$0/month',
    features: [
      'Basic Chat with Amarax Core Agent',
      'Limited RAG Agent Creation (1 Agent)',
      'Community Support',
      'Access to Public Agent Market (Usage Only)',
    ],
    ctaText: 'Get Started',
    themeColor: 'gray-600'
  },
  {
    id: 'creator',
    name: 'Creator Pro',
    price: '$29/month',
    features: [
      'Everything in Explorer, plus:',
      'Unlimited RAG Agent Creation',
      'Advanced Agent Customization',
      'Publish Agents to Market (Revenue Share)',
      'Priority Email Support',
      'Downloadable Desktop Client Access',
      'Early Access to New Features',
    ],
    ctaText: 'Choose Creator',
    isPopular: true,
    themeColor: 'amarax-blue'
  },
  {
    id: 'enterprise',
    name: 'Enterprise Suite',
    price: 'Custom Pricing',
    features: [
      'Everything in Creator Pro, plus:',
      'Dedicated Account Manager',
      'Team Collaboration Features',
      'Custom Integrations & API Access',
      'On-Premise Deployment Options',
      '24/7 Premium Support',
      'Volume Discounts',
    ],
    ctaText: 'Contact Sales',
    themeColor: 'amarax-purple'
  },
];

const SubscriptionTiersDisplay = () => {
  const handleSelectTier = (tierId: string) => {
    // TODO: Handle tier selection, e.g., navigate to checkout, contact form, or update user subscription state
    console.log(`Selected tier: ${tierId}`);
    alert(`You selected the ${tiers.find(t => t.id === tierId)?.name} tier. Integration with payment/signup flow is pending.`);
  };

  return (
    <div className="py-12 bg-gray-900 bg-opacity-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            Choose Your Amarax Central Plan
          </h2>
          <p className="mt-4 text-lg text-gray-400">
            Unlock powerful AI capabilities tailored to your needs.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
          {tiers.map((tier) => (
            <div
              key={tier.id}
              className={`relative flex flex-col rounded-xl shadow-2xl p-8 bg-gray-800 border-2 ${tier.isPopular ? `border-${tier.themeColor || 'amarax-blue'}` : 'border-gray-700'}`}
            >
              {tier.isPopular && (
                <div className={`absolute top-0 py-1.5 px-4 bg-${tier.themeColor || 'amarax-blue'} text-white rounded-full text-xs font-semibold uppercase tracking-wide transform -translate-y-1/2`}>
                  Most Popular
                </div>
              )}
              <h3 className="text-2xl font-semibold text-white">{tier.name}</h3>
              <p className={`mt-4 text-4xl font-extrabold text-white`}>{tier.price}</p>
              <p className="mt-1 text-sm text-gray-400">{tier.id === 'enterprise' ? 'Tailored for your business' : 'Billed monthly or annually'}</p>
              
              <ul className="mt-8 space-y-3 text-sm text-gray-300 flex-grow">
                {tier.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <svg className={`flex-shrink-0 h-5 w-5 text-${tier.themeColor || 'amarax-cyan'} mr-2`} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <button
                onClick={() => handleSelectTier(tier.id)}
                className={`mt-10 block w-full py-3 px-6 border border-transparent rounded-md text-center font-medium text-white bg-${tier.themeColor || 'gray-600'} hover:bg-opacity-80 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-${tier.themeColor || 'gray-500'}`}
              >
                {tier.ctaText}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SubscriptionTiersDisplay;

