"use client";

import React, { useState, useEffect } from 'react';
import Image from 'next/image';

// Interface for a market listing (should match backend response)
interface MarketListing {
  listing_id: number;
  agent_id: number;
  agent_name: string;
  publisher_user_id: number;
  publisher_username: string;
  title: string;
  market_description: string;
  category?: string;
  tags?: string[];
  price?: string; // Assuming price is a string like "0.00" or null
  version: string;
  mascot_display_url?: string;
  average_rating?: number;
  download_count?: number;
  published_at?: string;
}

const AgentMarketplace = () => {
  const [listings, setListings] = useState<MarketListing[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const defaultMascot = "/mascots/mascot_style_1.png"; // Default if no mascot_display_url

  useEffect(() => {
    const fetchListings = async () => {
      setLoading(true);
      setError(null);
      try {
        // TODO: Replace with actual API call to /api/v1/market/agents
        // const response = await fetch("/api/v1/market/agents");
        // if (!response.ok) {
        //   throw new Error(`Failed to fetch listings: ${response.statusText}`);
        // }
        // const data = await response.json();
        // setListings(data);

        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        const mockData: MarketListing[] = [
          {
            listing_id: 1,
            agent_id: 101,
            agent_name: "Super Productive Bot",
            publisher_user_id: 1,
            publisher_username: "Creator1",
            title: "Productivity Powerhouse Agent",
            market_description: "This agent will revolutionize your workflow and boost your productivity by 200%!",
            category: "Productivity",
            tags: ["task management", "automation", "efficiency"],
            price: "0.00",
            version: "1.2.0",
            mascot_display_url: "/mascots/mascot_style_2.png",
            average_rating: 4.5,
            download_count: 1250,
            published_at: new Date().toISOString(),
          },
          {
            listing_id: 2,
            agent_id: 102,
            agent_name: "Creative Writer Pro",
            publisher_user_id: 2,
            publisher_username: "WriterGal",
            title: "AI Story Weaver",
            market_description: "Unleash your creativity with this AI assistant for writing compelling stories, scripts, and articles.",
            category: "Creative",
            tags: ["writing", "content creation", "storytelling"],
            price: "4.99",
            version: "1.0.1",
            mascot_display_url: "/mascots/mascot_style_1.png", // Using another style
            average_rating: 4.8,
            download_count: 870,
            published_at: new Date(Date.now() - 86400000 * 5).toISOString(), // 5 days ago
          },
        ];
        setListings(mockData);

      } catch (err: any) {
        setError(err.message || "An unexpected error occurred.");
        console.error("Error fetching market listings:", err);
      }
      setLoading(false);
    };

    fetchListings();
  }, []);

  const filteredListings = listings.filter(listing => 
    listing.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    listing.market_description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (listing.tags && listing.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase())))
  );

  const handleAcquireAgent = async (listingId: number, title: string) => {
    // Placeholder for API call to /api/v1/market/agents/<listing_id>/acquire
    console.log(`Attempting to acquire agent: ${title} (ID: ${listingId})`);
    alert(`Simulating acquisition of "${title}". API call not yet implemented.`);
    // try {
    //   const token = localStorage.getItem("jwt_token");
    //   const response = await fetch(`/api/v1/market/agents/${listingId}/acquire`, {
    //     method: "POST",
    //     headers: {
    //       "Authorization": `Bearer ${token}`,
    //     }
    //   });
    //   if (response.ok) {
    //     alert(`Agent "${title}" acquired successfully!`);
    //     // Optionally, update UI or refetch user's acquired agents
    //   } else {
    //     const errorData = await response.json();
    //     alert(`Failed to acquire agent: ${errorData.msg || response.statusText}`);
    //   }
    // } catch (err) {
    //   alert("An error occurred while trying to acquire the agent.");
    // }
  };

  if (loading) {
    return <div className="p-6 text-center text-[rgb(var(--foreground-rgb))]"><div className="loading-spinner w-8 h-8 mx-auto"></div><p>Loading Agent Market...</p></div>;
  }

  if (error) {
    return <div className="p-6 text-center text-red-400">Error: {error}</div>;
  }

  return (
    <div className="p-4 md:p-6 bg-[rgba(var(--panel-background-rgb),0.7)] rounded-lg shadow-xl backdrop-blur-sm overflow-y-auto h-full">
      <h2 className="text-xl md:text-2xl font-semibold text-[rgb(var(--foreground-rgb))] mb-4 md:mb-6">Agent Marketplace</h2>
      
      <div className="mb-4">
        <input 
          type="text"
          placeholder="Search agents by name, description, or tags..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full px-4 py-2.5 bg-[rgb(var(--input-background-rgb))] border border-[rgb(var(--border-rgb))] rounded-lg text-[rgb(var(--foreground-rgb))] placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[rgb(var(--amarax-cyan-highlight))] focus:border-[rgb(var(--amarax-cyan-highlight))]"
        />
      </div>

      {filteredListings.length === 0 && searchTerm && (
        <p className="text-center text-gray-400 py-4">No agents found matching your search criteria.</p>
      )}
      {filteredListings.length === 0 && !searchTerm && (
        <p className="text-center text-gray-400 py-4">The marketplace is currently empty. Check back soon!</p>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        {filteredListings.map((listing) => (
          <div 
            key={listing.listing_id} 
            className="bg-[rgb(var(--input-background-rgb))] rounded-lg shadow-lg overflow-hidden border border-[rgb(var(--border-rgb))] flex flex-col transition-all hover:shadow-2xl hover:border-[rgb(var(--amarax-cyan-highlight))]"
          >
            <div className="p-4 flex items-center space-x-3 bg-[rgba(var(--panel-background-rgb),0.5)] border-b border-[rgb(var(--border-rgb))]">
              <Image 
                src={listing.mascot_display_url || defaultMascot} 
                alt={`${listing.title} Mascot`} 
                width={48} 
                height={48} 
                className="rounded-md mascot-image bg-[rgba(var(--border-rgb),0.3)]"
              />
              <div>
                <h3 className="text-lg font-semibold text-[rgb(var(--foreground-rgb))]">{listing.title}</h3>
                <p className="text-xs text-gray-400">By: {listing.publisher_username} | v{listing.version}</p>
              </div>
            </div>
            <div className="p-4 flex-grow">
              <p className="text-sm text-gray-300 mb-3 min-h-[60px]">{listing.market_description}</p>
              {listing.category && <p className="text-xs text-gray-400 mb-1"><span className="font-semibold">Category:</span> {listing.category}</p>}
              {listing.tags && listing.tags.length > 0 && (
                <div className="mb-2">
                  {listing.tags.map(tag => (
                    <span key={tag} className="inline-block bg-[rgb(var(--amarax-purple-primary))] bg-opacity-30 text-[rgb(var(--amarax-purple-primary))] text-xs px-2 py-0.5 rounded-full mr-1 mb-1">{tag}</span>
                  ))}
                </div>
              )}
            </div>
            <div className="p-4 border-t border-[rgb(var(--border-rgb))] bg-[rgba(var(--panel-background-rgb),0.3)] flex justify-between items-center">
              <p className="text-lg font-bold text-[rgb(var(--amarax-gold-accent))]">
                {listing.price === "0.00" || !listing.price ? "Free" : `$${listing.price}`}
              </p>
              <button 
                onClick={() => handleAcquireAgent(listing.listing_id, listing.title)}
                className="px-4 py-2 bg-[rgb(var(--amarax-blue-accent))] hover:bg-opacity-80 text-white text-sm font-semibold rounded-md focus:outline-none focus:ring-2 focus:ring-[rgb(var(--amarax-blue-accent))] focus:ring-opacity-60 transition-colors duration-150"
              >
                {listing.price === "0.00" || !listing.price ? "Get Agent" : "Buy Agent"}
              </button>
            </div>
             <div className="px-4 py-2 text-xs text-gray-500 flex justify-between bg-[rgba(var(--panel-background-rgb),0.1)]">
                <span>Rating: {listing.average_rating ? `${listing.average_rating.toFixed(1)}/5.0` : "N/A"}</span>
                <span>Downloads: {listing.download_count || 0}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AgentMarketplace;

