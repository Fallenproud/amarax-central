"use client";

import React, { useState } from 'react';

const LoginForm = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    // TODO: Replace with actual API call to backend /auth/login
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log('Login attempt with:', { email, password });
      // if (response.ok) {
      //   const data = await response.json();
      //   localStorage.setItem('amarax_token', data.access_token);
      //   // TODO: Redirect to dashboard or update auth state
      //   console.log('Login successful', data);
      // } else {
      //   const errorData = await response.json();
      //   setError(errorData.message || 'Login failed');
      // }
      setError('Simulated login. API not connected.'); // Placeholder
    } catch (err) {
      setError('An unexpected error occurred.');
      console.error(err);
    }
    setLoading(false);
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-gray-800 bg-opacity-70 rounded-lg shadow-xl">
      <h2 className="text-2xl font-semibold text-white text-center mb-6">Login to Amarax Central</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-300">Email Address</label>
          <input
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-1 block w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-amarax-blue focus:border-amarax-blue sm:text-sm"
            placeholder="you@example.com"
          />
        </div>
        <div>
          <label htmlFor="password" className="block text-sm font-medium text-gray-300">Password</label>
          <input
            id="password"
            name="password"
            type="password"
            autoComplete="current-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-1 block w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-amarax-blue focus:border-amarax-blue sm:text-sm"
            placeholder="••••••••"
          />
        </div>
        {error && <p className="text-sm text-red-400">{error}</p>}
        <div>
          <button
            type="submit"
            disabled={loading}
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-amarax-blue hover:bg-opacity-80 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-amarax-blue disabled:opacity-50"
          >
            {loading ? 'Logging in...' : 'Login'}
          </button>
        </div>
      </form>
      <p className="mt-4 text-center text-sm text-gray-400">
        Don\'t have an account?{' '}
        {/* TODO: Link to registration page/component */}
        <a href="#" className="font-medium text-amarax-cyan hover:text-opacity-80">
          Sign up
        </a>
      </p>
    </div>
  );
};

export default LoginForm;

