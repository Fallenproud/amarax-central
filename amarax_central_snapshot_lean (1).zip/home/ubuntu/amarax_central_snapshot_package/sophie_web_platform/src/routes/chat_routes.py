from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models import db, ChatHistory, ChatMessage, User, RagAgent
from datetime import datetime
import uuid # For generating session IDs

chat_bp = Blueprint("chat", __name__)

@chat_bp.route("/send_message", methods=["POST"])
@jwt_required()
def send_message():
    current_user_id = get_jwt_identity()
    data = request.get_json()

    user_message_content = data.get("message")
    agent_id = data.get("agent_id") # Can be null for general Sophie chat
    session_id = data.get("session_id")

    if not user_message_content:
        return jsonify({"msg": "Message content is required"}), 400

    # Find or create chat history
    if not session_id:
        session_id = str(uuid.uuid4())
        chat_history = ChatHistory(
            user_id=current_user_id,
            agent_id=agent_id,
            session_id=session_id
        )
        db.session.add(chat_history)
        # Commit here to get chat_history.chat_id if it's autoincremented and needed immediately
        # However, it's often better to commit once after all related objects are added.
    else:
        chat_history = ChatHistory.query.filter_by(session_id=session_id, user_id=current_user_id).first()
        if not chat_history:
            # If session_id is provided but not found for the user, create a new one.
            # Or, you could return an error, depending on desired behavior.
            chat_history = ChatHistory(
                user_id=current_user_id,
                agent_id=agent_id,
                session_id=session_id
            )
            db.session.add(chat_history)
    
    # Save user message
    user_message = ChatMessage(
        chat_id=chat_history.chat_id, # This requires chat_history to have an ID, so commit might be needed earlier or handle differently
        sender="user",
        message_content=user_message_content
    )
    # db.session.add(user_message) # Add later after potential commit of chat_history

    # Placeholder for AI response logic
    # This is where you would call your LLM/RAG logic
    # For now, just echoing the message or a canned response
    ai_reply_content = f"Sophie received: {user_message_content}"
    if agent_id:
        agent = RagAgent.query.get(agent_id)
        if agent:
            ai_reply_content = f"{agent.agent_name} received: {user_message_content}" 
            # Add RAG logic here: retrieve context from agent.knowledge_base_id, then call LLM
        else:
            ai_reply_content = f"Agent with ID {agent_id} not found. Sophie received: {user_message_content}"

    # Save AI reply
    ai_message = ChatMessage(
        chat_id=chat_history.chat_id, # Same as above regarding chat_history.chat_id
        sender="sophie" if not agent_id else (RagAgent.query.get(agent_id).agent_name if RagAgent.query.get(agent_id) else "sophie"),
        message_content=ai_reply_content
    )
    # db.session.add(ai_message)

    # Commit all changes: new chat_history (if any), user_message, ai_message
    try:
        if chat_history.chat_id is None: # If it's a new ChatHistory instance not yet committed
            db.session.add(chat_history)
            db.session.flush() # Assigns an ID to chat_history without full commit
        
        user_message.chat_id = chat_history.chat_id
        ai_message.chat_id = chat_history.chat_id
        db.session.add(user_message)
        db.session.add(ai_message)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        return jsonify({"msg": "Error processing message", "error": str(e)}), 500

    return jsonify({
        "reply": ai_reply_content,
        "session_id": session_id,
        "user_message_id": user_message.message_id,
        "ai_message_id": ai_message.message_id
    }), 200

@chat_bp.route("/history/<session_id>", methods=["GET"])
@jwt_required()
def get_chat_history(session_id):
    current_user_id = get_jwt_identity()
    chat_history = ChatHistory.query.filter_by(session_id=session_id, user_id=current_user_id).first()

    if not chat_history:
        return jsonify({"msg": "Chat session not found"}), 404

    messages = ChatMessage.query.filter_by(chat_id=chat_history.chat_id).order_by(ChatMessage.timestamp.asc()).all()
    
    return jsonify([{
        "message_id": msg.message_id,
        "sender": msg.sender,
        "message_content": msg.message_content,
        "timestamp": msg.timestamp.isoformat(),
        "metadata": msg.metadata
    } for msg in messages]), 200

@chat_bp.route("/sessions", methods=["GET"])
@jwt_required()
def list_chat_sessions():
    current_user_id = get_jwt_identity()
    sessions = ChatHistory.query.filter_by(user_id=current_user_id).order_by(ChatHistory.updated_at.desc()).all()
    
    return jsonify([{
        "session_id": session.session_id,
        "agent_id": session.agent_id,
        "agent_name": RagAgent.query.get(session.agent_id).agent_name if session.agent_id and RagAgent.query.get(session.agent_id) else None,
        "last_message_preview": ChatMessage.query.filter_by(chat_id=session.chat_id).order_by(ChatMessage.timestamp.desc()).first().message_content if ChatMessage.query.filter_by(chat_id=session.chat_id).count() > 0 else "No messages yet",
        "created_at": session.created_at.isoformat(),
        "updated_at": session.updated_at.isoformat()
    } for session in sessions]), 200


