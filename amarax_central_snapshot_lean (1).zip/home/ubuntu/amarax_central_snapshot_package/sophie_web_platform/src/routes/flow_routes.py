from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models import db, Flow, User

flow_bp = Blueprint("flows", __name__)

@flow_bp.route("/", methods=["POST"])
@jwt_required()
def create_flow():
    current_user_id = get_jwt_identity()
    data = request.get_json()

    flow_name = data.get("flow_name")
    flow_description = data.get("flow_description")
    flow_definition = data.get("flow_definition") # This will be the JSON structure of the flow
    is_public = data.get("is_public", False)

    if not flow_name or flow_definition is None:
        return jsonify({"msg": "Flow name and definition are required"}), 400

    new_flow = Flow(
        user_id=current_user_id,
        flow_name=flow_name,
        flow_description=flow_description,
        flow_definition=flow_definition,
        is_public=is_public
    )
    db.session.add(new_flow)
    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        return jsonify({"msg": "Error creating flow", "error": str(e)}), 500

    return jsonify({
        "msg": "Flow created successfully", 
        "flow_id": new_flow.flow_id,
        "flow_name": new_flow.flow_name
    }), 201

@flow_bp.route("/", methods=["GET"])
@jwt_required()
def get_user_flows():
    current_user_id = get_jwt_identity()
    flows = Flow.query.filter_by(user_id=current_user_id).all()
    return jsonify([{
        "flow_id": flow.flow_id,
        "flow_name": flow.flow_name,
        "flow_description": flow.flow_description,
        "is_public": flow.is_public,
        "created_at": flow.created_at.isoformat(),
        "updated_at": flow.updated_at.isoformat()
    } for flow in flows]), 200

@flow_bp.route("/<int:flow_id>", methods=["GET"])
@jwt_required()
def get_flow_details(flow_id):
    current_user_id = get_jwt_identity()
    flow = Flow.query.filter_by(flow_id=flow_id, user_id=current_user_id).first_or_404()
    return jsonify({
        "flow_id": flow.flow_id,
        "flow_name": flow.flow_name,
        "flow_description": flow.flow_description,
        "flow_definition": flow.flow_definition, # Return the full definition for editing/viewing
        "is_public": flow.is_public,
        "created_at": flow.created_at.isoformat(),
        "updated_at": flow.updated_at.isoformat()
    }), 200

@flow_bp.route("/<int:flow_id>", methods=["PUT"])
@jwt_required()
def update_flow(flow_id):
    current_user_id = get_jwt_identity()
    flow = Flow.query.filter_by(flow_id=flow_id, user_id=current_user_id).first_or_404()
    data = request.get_json()

    flow.flow_name = data.get("flow_name", flow.flow_name)
    flow.flow_description = data.get("flow_description", flow.flow_description)
    flow.flow_definition = data.get("flow_definition", flow.flow_definition)
    flow.is_public = data.get("is_public", flow.is_public)

    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        return jsonify({"msg": "Error updating flow", "error": str(e)}), 500

    return jsonify({"msg": "Flow updated successfully"}), 200

@flow_bp.route("/<int:flow_id>", methods=["DELETE"])
@jwt_required()
def delete_flow(flow_id):
    current_user_id = get_jwt_identity()
    flow = Flow.query.filter_by(flow_id=flow_id, user_id=current_user_id).first_or_404()
    
    # Consider if associated executions should be deleted or archived
    # For now, just deleting the flow itself
    db.session.delete(flow)
    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        return jsonify({"msg": "Error deleting flow", "error": str(e)}), 500
            
    return jsonify({"msg": "Flow deleted successfully"}), 200

# TODO: Add endpoints for flow execution (POST /flows/<flow_id>/execute and GET /flows/executions/<execution_id>)

