from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models import db, RagAgent, KnowledgeBase, User # Assuming User is needed for ownership

rag_bp = Blueprint("rag_agents", __name__)

@rag_bp.route("/", methods=["POST"])
@jwt_required()
def create_rag_agent():
    current_user_id = get_jwt_identity()
    data = request.get_json()

    agent_name = data.get("agent_name")
    description = data.get("description")
    system_prompt = data.get("system_prompt")
    kb_name = data.get("knowledge_base_name") # User provides a name for a new KB
    mascot_avatar_url = data.get("mascot_avatar_url") # New field

    if not agent_name or not kb_name:
        return jsonify({"msg": "Agent name and knowledge base name are required"}), 400

    # Create a new KnowledgeBase for this agent
    # For simplicity, vector_store_namespace can be derived or be a UUID
    # In a real app, ensure this namespace is unique and managed properly
    vector_store_namespace = f"kb_{current_user_id}_{kb_name.lower().replace(" ", "_")}"
    
    existing_kb = KnowledgeBase.query.filter_by(vector_store_namespace=vector_store_namespace).first()
    if existing_kb:
        return jsonify({"msg": f"Knowledge base with name 	'{kb_name}	' resulting in namespace 	'{vector_store_namespace}	' already exists. Try a different name."}), 400

    knowledge_base = KnowledgeBase(
        user_id=current_user_id,
        kb_name=kb_name,
        vector_store_namespace=vector_store_namespace
    )
    db.session.add(knowledge_base)
    # We need to commit here to get the knowledge_base.kb_id if it's autoincremented
    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        return jsonify({"msg": "Error creating knowledge base", "error": str(e)}), 500

    new_agent = RagAgent(
        user_id=current_user_id,
        agent_name=agent_name,
        description=description,
        system_prompt=system_prompt,
        knowledge_base_id=knowledge_base.kb_id,
        mascot_avatar_url=mascot_avatar_url # Save new field
    )
    db.session.add(new_agent)
    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        # Clean up the created knowledge_base if agent creation fails
        db.session.delete(knowledge_base)
        db.session.commit()
        return jsonify({"msg": "Error creating RAG agent", "error": str(e)}), 500

    return jsonify({"msg": "RAG Agent created successfully", "agent_id": new_agent.agent_id, "mascot_avatar_url": new_agent.mascot_avatar_url}), 201

@rag_bp.route("/", methods=["GET"])
@jwt_required()
def get_rag_agents():
    current_user_id = get_jwt_identity()
    agents = RagAgent.query.filter_by(user_id=current_user_id).all()
    return jsonify([{
        "agent_id": agent.agent_id,
        "agent_name": agent.agent_name,
        "description": agent.description,
        "knowledge_base_id": agent.knowledge_base_id,
        "mascot_avatar_url": agent.mascot_avatar_url, # Return new field
        "created_at": agent.created_at.isoformat()
    } for agent in agents]), 200

@rag_bp.route("/<int:agent_id>", methods=["GET"])
@jwt_required()
def get_rag_agent_details(agent_id):
    current_user_id = get_jwt_identity()
    agent = RagAgent.query.filter_by(agent_id=agent_id, user_id=current_user_id).first_or_404()
    kb = KnowledgeBase.query.get(agent.knowledge_base_id)
    return jsonify({
        "agent_id": agent.agent_id,
        "agent_name": agent.agent_name,
        "description": agent.description,
        "system_prompt": agent.system_prompt,
        "knowledge_base_id": agent.knowledge_base_id,
        "knowledge_base_name": kb.kb_name if kb else None,
        "mascot_avatar_url": agent.mascot_avatar_url, # Return new field
        "is_public": agent.is_public,
        "created_at": agent.created_at.isoformat()
    }), 200

@rag_bp.route("/<int:agent_id>", methods=["PUT"])
@jwt_required()
def update_rag_agent(agent_id):
    current_user_id = get_jwt_identity()
    agent = RagAgent.query.filter_by(agent_id=agent_id, user_id=current_user_id).first_or_404()
    data = request.get_json()

    agent.agent_name = data.get("agent_name", agent.agent_name)
    agent.description = data.get("description", agent.description)
    agent.system_prompt = data.get("system_prompt", agent.system_prompt)
    agent.is_public = data.get("is_public", agent.is_public)
    agent.mascot_avatar_url = data.get("mascot_avatar_url", agent.mascot_avatar_url) # Update new field
    # Note: Changing knowledge_base_id might be complex and require careful handling

    db.session.commit()
    return jsonify({"msg": "RAG Agent updated successfully", "mascot_avatar_url": agent.mascot_avatar_url}), 200

@rag_bp.route("/<int:agent_id>", methods=["DELETE"])
@jwt_required()
def delete_rag_agent(agent_id):
    current_user_id = get_jwt_identity()
    agent = RagAgent.query.filter_by(agent_id=agent_id, user_id=current_user_id).first_or_404()
    
    # Optionally, decide if deleting an agent also deletes its knowledge base
    # For now, let's assume it does if no other agent uses it.
    kb_id_to_check = agent.knowledge_base_id
    
    db.session.delete(agent)
    db.session.commit() # Commit deletion of agent first

    # Check if the knowledge base is orphaned
    other_agents_using_kb = RagAgent.query.filter_by(knowledge_base_id=kb_id_to_check).first()
    if not other_agents_using_kb:
        kb_to_delete = KnowledgeBase.query.get(kb_id_to_check)
        if kb_to_delete:
            # Here you would also trigger deletion of documents from vector store and file system
            # For now, just deleting the DB record
            db.session.delete(kb_to_delete)
            db.session.commit()
            
    return jsonify({"msg": "RAG Agent deleted successfully"}), 200

# Further endpoints for managing documents within an agent's knowledge base will be added here.
# e.g., POST /rag_agents/<agent_id>/kb/upload_doc

