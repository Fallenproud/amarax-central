from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models import db, AgentMarketListing, UserAcquiredAgent, RagAgent, User
from datetime import datetime

market_bp = Blueprint("market_agents", __name__)

@market_bp.route("/publish/<int:agent_id>", methods=["POST"])
@jwt_required()
def publish_agent_to_market(agent_id):
    current_user_id = get_jwt_identity()
    data = request.get_json()

    # Verify the agent exists and belongs to the current user
    agent_to_publish = RagAgent.query.filter_by(agent_id=agent_id, user_id=current_user_id).first()
    if not agent_to_publish:
        return jsonify({"msg": "RAG Agent not found or you do not own this agent"}), 404

    title = data.get("title")
    market_description = data.get("market_description")
    category = data.get("category")
    tags = data.get("tags") # Expected to be a list of strings
    price = data.get("price") # Should be a number or null
    version = data.get("version", "1.0.0")
    mascot_display_url = data.get("mascot_display_url", agent_to_publish.mascot_avatar_url) # Default to agent's mascot

    if not title or not market_description:
        return jsonify({"msg": "Title and market description are required for listing"}), 400
    
    # Check if this agent is already listed by this user
    existing_listing = AgentMarketListing.query.filter_by(agent_id=agent_id, publisher_user_id=current_user_id).first()
    if existing_listing:
        return jsonify({"msg": "This agent is already listed in the market by you. You can update the existing listing."}), 409

    new_listing = AgentMarketListing(
        agent_id=agent_id,
        publisher_user_id=current_user_id,
        title=title,
        market_description=market_description,
        category=category,
        tags=tags,
        price=price,
        version=version,
        mascot_display_url=mascot_display_url,
        status="published", # Or "under_review" if a review process is implemented
        published_at=datetime.utcnow()
    )
    db.session.add(new_listing)
    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        return jsonify({"msg": "Error publishing agent to market", "error": str(e)}), 500

    return jsonify({"msg": "Agent published to market successfully", "listing_id": new_listing.listing_id}), 201

@market_bp.route("/", methods=["GET"])
# No jwt_required here if market is publicly browsable, or add if login needed to browse
def get_market_listings():
    # Add pagination, filtering, and searching later
    listings = AgentMarketListing.query.filter_by(status="published").order_by(AgentMarketListing.published_at.desc()).all()
    
    output = []
    for listing in listings:
        agent = RagAgent.query.get(listing.agent_id)
        publisher = User.query.get(listing.publisher_user_id)
        output.append({
            "listing_id": listing.listing_id,
            "agent_id": listing.agent_id,
            "agent_name": agent.agent_name if agent else "N/A",
            "publisher_user_id": listing.publisher_user_id,
            "publisher_username": publisher.username if publisher else "N/A",
            "title": listing.title,
            "market_description": listing.market_description,
            "category": listing.category,
            "tags": listing.tags,
            "price": str(listing.price) if listing.price is not None else None, # Ensure Decimal is serialized
            "version": listing.version,
            "mascot_display_url": listing.mascot_display_url,
            "average_rating": listing.average_rating,
            "download_count": listing.download_count,
            "published_at": listing.published_at.isoformat() if listing.published_at else None
        })
    return jsonify(output), 200

@market_bp.route("/<int:listing_id>", methods=["GET"])
# No jwt_required here if market is publicly browsable
def get_market_listing_details(listing_id):
    listing = AgentMarketListing.query.filter_by(listing_id=listing_id, status="published").first_or_404()
    agent = RagAgent.query.get(listing.agent_id)
    publisher = User.query.get(listing.publisher_user_id)

    return jsonify({
        "listing_id": listing.listing_id,
        "agent_id": listing.agent_id,
        "agent_name": agent.agent_name if agent else "N/A",
        "agent_description": agent.description if agent else "N/A",
        "publisher_user_id": listing.publisher_user_id,
        "publisher_username": publisher.username if publisher else "N/A",
        "title": listing.title,
        "market_description": listing.market_description,
        "category": listing.category,
        "tags": listing.tags,
        "price": str(listing.price) if listing.price is not None else None,
        "version": listing.version,
        "mascot_display_url": listing.mascot_display_url,
        "system_prompt_preview": agent.system_prompt[:200] + "..." if agent and agent.system_prompt else None, # Example preview
        "average_rating": listing.average_rating,
        "download_count": listing.download_count,
        "published_at": listing.published_at.isoformat() if listing.published_at else None
    }), 200

@market_bp.route("/<int:listing_id>", methods=["PUT"])
@jwt_required()
def update_market_listing(listing_id):
    current_user_id = get_jwt_identity()
    listing = AgentMarketListing.query.filter_by(listing_id=listing_id, publisher_user_id=current_user_id).first_or_404()
    data = request.get_json()

    listing.title = data.get("title", listing.title)
    listing.market_description = data.get("market_description", listing.market_description)
    listing.category = data.get("category", listing.category)
    listing.tags = data.get("tags", listing.tags)
    listing.price = data.get("price", listing.price)
    listing.version = data.get("version", listing.version)
    listing.mascot_display_url = data.get("mascot_display_url", listing.mascot_display_url)
    listing.status = data.get("status", listing.status) # e.g., to unpublish or resubmit

    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        return jsonify({"msg": "Error updating market listing", "error": str(e)}), 500

    return jsonify({"msg": "Market listing updated successfully"}), 200

@market_bp.route("/<int:listing_id>/acquire", methods=["POST"])
@jwt_required()
def acquire_agent_from_market(listing_id):
    current_user_id = get_jwt_identity()
    listing = AgentMarketListing.query.filter_by(listing_id=listing_id, status="published").first()

    if not listing:
        return jsonify({"msg": "Market listing not found or not available"}), 404

    # Check if user already acquired this agent
    already_acquired = UserAcquiredAgent.query.filter_by(user_id=current_user_id, listing_id=listing_id).first()
    if already_acquired:
        return jsonify({"msg": "You have already acquired this agent"}), 409

    # TODO: Implement payment logic if listing.price > 0
    if listing.price and float(listing.price) > 0:
        return jsonify({"msg": "Paid agent acquisition not yet implemented"}), 501

    new_acquisition = UserAcquiredAgent(
        user_id=current_user_id,
        listing_id=listing_id,
        purchase_price=listing.price # Record price at time of acquisition
    )
    listing.download_count = (listing.download_count or 0) + 1 # Increment download/acquisition count
    
    db.session.add(new_acquisition)
    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        return jsonify({"msg": "Error acquiring agent", "error": str(e)}), 500

    return jsonify({"msg": f"Agent 	'{listing.title}	' acquired successfully"}), 200

@market_bp.route("/my_published", methods=["GET"])
@jwt_required()
def get_my_published_listings():
    current_user_id = get_jwt_identity()
    listings = AgentMarketListing.query.filter_by(publisher_user_id=current_user_id).all()
    # Similar output to get_market_listings, but filtered for the current user
    output = []
    for listing in listings:
        output.append({
            "listing_id": listing.listing_id,
            "agent_id": listing.agent_id,
            "title": listing.title,
            "status": listing.status,
            "version": listing.version,
            "price": str(listing.price) if listing.price is not None else None,
            "published_at": listing.published_at.isoformat() if listing.published_at else None
        })
    return jsonify(output), 200

@market_bp.route("/my_acquired", methods=["GET"])
@jwt_required()
def get_my_acquired_agents():
    current_user_id = get_jwt_identity()
    acquisitions = UserAcquiredAgent.query.filter_by(user_id=current_user_id).all()
    output = []
    for acq in acquisitions:
        listing = AgentMarketListing.query.get(acq.listing_id)
        if listing:
            agent = RagAgent.query.get(listing.agent_id)
            output.append({
                "acquisition_id": acq.acquisition_id,
                "listing_id": acq.listing_id,
                "agent_id": listing.agent_id,
                "title": listing.title,
                "version": listing.version,
                "acquired_at": acq.acquired_at.isoformat(),
                "mascot_display_url": listing.mascot_display_url,
                "agent_name": agent.agent_name if agent else "N/A"
            })
    return jsonify(output), 200

