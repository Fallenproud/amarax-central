import os
import sys
from datetime import timedelta

# DON\\'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory
from flask_jwt_extended import JWTManager

from src.models import db, User # Import User to ensure it\\\'s known by SQLAlchemy
from src.models.user import bcrypt # Import bcrypt from where it\\\'s initialized
from src.routes.auth import auth_bp
from src.routes.user import user_bp # Original user blueprint, might need adjustments
from src.routes.rag_routes import rag_bp # Import the RAG blueprint
from src.routes.chat_routes import chat_bp # Import the Chat blueprint

# Import all model files to ensure SQLAlchemy registers them for db.create_all()
from src.models import subscription, rag, chat

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), \\\'static\\\
))

# Configuration
app.config["SECRET_KEY"] = os.getenv("FLASK_SECRET_KEY", "super-secret-sophie-key-change-me") # Use environment variable for production
app.config["SQLALCHEMY_DATABASE_URI"] = f"mysql+pymysql://{os.getenv(\\\'DB_USERNAME\\\
	, \\\r	oot\\\
	)}:{os.getenv(\\\'DB_PASSWORD\\\
	, \\\p	assword\\\
	)}@{os.getenv(\\\'DB_HOST\\\
	, \\\l	ocalhost\\\
	)}:{os.getenv(\\\'DB_PORT\\\
	, \\\3	306\\\
	)}/{os.getenv(\\\'DB_NAME\\\
	, \\\m	ydb\\\
	)}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["JWT_SECRET_KEY"] = os.getenv("JWT_SECRET_KEY", "super-secret-jwt-key-change-me") # Use environment variable
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(hours=1) # Example expiration

# Initialize extensions
db.init_app(app)
bcrypt.init_app(app)
jwt = JWTManager(app)

# Register Blueprints
app.register_blueprint(auth_bp, url_prefix=\\\'/api/auth\\\
)
app.register_blueprint(user_bp, url_prefix=\\\'/api/users\\\
) # Adjusted prefix for consistency
app.register_blueprint(rag_bp, url_prefix=\\\'/api/rag_agents\\\
) # Register RAG blueprint
app.register_blueprint(chat_bp, url_prefix=\\\'/api/chat\\\
) # Register Chat blueprint

with app.app_context():
    db.create_all() # Create database tables for all models

@app.route(\\\	/\\\		, defaults={\\\		path\\\		: \\\\		\\\		}) # type: ignore
@app.route(\\\	/<path:path>\\\		) # type: ignore
def serve(path: str):
    static_folder_path = app.static_folder
    if static_folder_path is None:
        return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, \\\i	ndex.html\\\
	)
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, \\\i	ndex.html\\\
	)
        else:
            if path.startswith("api/"):
                return "API endpoint not found", 404
            return "index.html not found in static folder", 404

if __name__ == \\\m	ain\\\		:
    app.run(host=\\\'0.0.0.0\\\
	, port=5000, debug=True)

