from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from .user import db # Import db instance

class KnowledgeBase(db.Model):
    __tablename__ = "knowledge_bases"

    kb_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=False)
    kb_name = db.Column(db.String(255), nullable=False)
    vector_store_namespace = db.Column(db.String(255), unique=True, nullable=False) # Identifier for ChromaDB/FAISS
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship("User", backref="knowledge_bases", lazy=True)

    def __repr__(self):
        return f"<KnowledgeBase {self.kb_name}>"

class RagAgent(db.Model):
    __tablename__ = "rag_agents"

    agent_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=False)
    agent_name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    system_prompt = db.Column(db.Text, nullable=True)
    knowledge_base_id = db.Column(db.Integer, db.ForeignKey("knowledge_bases.kb_id"), nullable=False)
    mascot_avatar_url = db.Column(db.String(512), nullable=True) # Path/URL to the agent's chosen mascot image
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_public = db.Column(db.Boolean, default=False)

    user = db.relationship("User", backref="rag_agents", lazy=True)
    knowledge_base = db.relationship("KnowledgeBase", backref="rag_agents", lazy=True)

    def __repr__(self):
        return f"<RagAgent {self.agent_name}>"

class KnowledgeBaseDocument(db.Model):
    __tablename__ = "knowledge_base_documents"

    doc_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    kb_id = db.Column(db.Integer, db.ForeignKey("knowledge_bases.kb_id"), nullable=False)
    file_name = db.Column(db.String(255), nullable=False)
    file_path_on_server = db.Column(db.String(512), nullable=False)
    status = db.Column(db.String(50), nullable=False, default="pending_processing") # e.g., "pending_processing", "processing", "processed", "error"
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    metadata = db.Column(db.JSON, nullable=True)

    knowledge_base = db.relationship("KnowledgeBase", backref="documents", lazy=True)

    def __repr__(self):
        return f"<KnowledgeBaseDocument {self.file_name} for KB {self.kb_id}>"

