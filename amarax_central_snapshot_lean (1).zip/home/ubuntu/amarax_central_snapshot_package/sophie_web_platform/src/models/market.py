from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from .user import db # Import db instance
from .rag import RagAgent # Import RagAgent for ForeignKey

class AgentMarketListing(db.Model):
    __tablename__ = "agent_market_listings"

    listing_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    agent_id = db.Column(db.Integer, db.ForeignKey("rag_agents.agent_id"), nullable=False)
    publisher_user_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    market_description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(100), nullable=True)
    tags = db.Column(db.JSON, nullable=True) # Storing tags as a JSON array
    price = db.Column(db.Numeric(10, 2), nullable=True) # For paid agents, NULL or 0 for free
    version = db.Column(db.String(50), nullable=False, default="1.0.0")
    mascot_display_url = db.Column(db.String(512), nullable=True) # Specific mascot for market display
    status = db.Column(db.String(50), nullable=False, default="unpublished") # e.g., "published", "unpublished", "under_review"
    published_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    average_rating = db.Column(db.Float, nullable=True)
    download_count = db.Column(db.Integer, default=0)

    # Relationships
    agent = db.relationship("RagAgent", backref="market_listings")
    publisher = db.relationship("User", backref="published_market_listings")

    def __repr__(self):
        return f"<AgentMarketListing {self.title} by User {self.publisher_user_id}>"

class UserAcquiredAgent(db.Model):
    __tablename__ = "user_acquired_agents"

    acquisition_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=False)
    listing_id = db.Column(db.Integer, db.ForeignKey("agent_market_listings.listing_id"), nullable=False)
    # acquired_agent_id might not be needed if the listing_id and user_id are enough to grant access
    # or it could point to a user-specific copy/instance if agents are duplicated on acquisition.
    # For simplicity, we assume access is granted via the listing.
    acquired_at = db.Column(db.DateTime, default=datetime.utcnow)
    purchase_price = db.Column(db.Numeric(10, 2), nullable=True) # Price at the time of acquisition

    # Relationships
    user = db.relationship("User", backref="acquired_agents_associations")
    listing = db.relationship("AgentMarketListing", backref="acquisitions")

    def __repr__(self):
        return f"<UserAcquiredAgent User {self.user_id} acquired Listing {self.listing_id}>"

# Potential future model: AgentReview / AgentRating
# class AgentRating(db.Model):
#     __tablename__ = "agent_ratings"
#     rating_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
#     listing_id = db.Column(db.Integer, db.ForeignKey("agent_market_listings.listing_id"), nullable=False)
#     user_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=False)
#     rating = db.Column(db.Integer, nullable=False) # e.g., 1-5 stars
#     review_text = db.Column(db.Text, nullable=True)
#     created_at = db.Column(db.DateTime, default=datetime.utcnow)

#     listing = db.relationship("AgentMarketListing", backref="ratings")
#     user = db.relationship("User", backref="agent_ratings")

