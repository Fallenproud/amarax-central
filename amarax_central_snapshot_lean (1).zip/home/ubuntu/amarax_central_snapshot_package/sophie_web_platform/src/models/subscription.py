from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from .user import db # Import db instance from user.py or a central models.py

class SubscriptionTier(db.Model):
    __tablename__ = "subscription_tiers"

    tier_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(80), unique=True, nullable=False) # e.g., "Free", "Basic", "Premium"
    price_monthly = db.Column(db.Numeric(10, 2), nullable=True)
    price_annually = db.Column(db.Numeric(10, 2), nullable=True)
    features = db.Column(db.JSON, nullable=True) # e.g., RAG agent limits, downloadable client access

    def __repr__(self):
        return f"<SubscriptionTier {self.name}>"

class Subscription(db.Model):
    __tablename__ = "subscriptions"

    subscription_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=False)
    tier_id = db.Column(db.Integer, db.ForeignKey("subscription_tiers.tier_id"), nullable=False)
    start_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    end_date = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(50), nullable=False, default="pending_payment") # e.g., "active", "cancelled", "expired", "pending_payment"
    payment_gateway_subscription_id = db.Column(db.String(255), nullable=True) # ID from Stripe, etc.
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship("User", backref=db.backref("subscription", uselist=False, lazy=True))
    tier = db.relationship("SubscriptionTier", backref="subscriptions", lazy=True)

    def __repr__(self):
        return f"<Subscription {self.subscription_id} for User {self.user_id}>"

