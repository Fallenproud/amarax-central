from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from .user import db # Import db instance

class ChatHistory(db.Model):
    __tablename__ = "chat_histories"

    chat_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=False)
    agent_id = db.Column(db.Integer, db.ForeignKey("rag_agents.agent_id"), nullable=True) # If chatting with a specific RAG agent
    session_id = db.Column(db.String(255), nullable=False, index=True) # To group messages in a conversation
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship("User", backref="chat_histories", lazy=True)
    rag_agent = db.relationship("RagAgent", backref="chat_histories", lazy=True)

    def __repr__(self):
        return f"<ChatHistory {self.chat_id} for Session {self.session_id}>"

class ChatMessage(db.Model):
    __tablename__ = "chat_messages"

    message_id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    chat_id = db.Column(db.Integer, db.ForeignKey("chat_histories.chat_id"), nullable=False)
    sender = db.Column(db.String(80), nullable=False) # "user" or "sophie" or "agent_name"
    message_content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    metadata = db.Column(db.JSON, nullable=True) # e.g., sources for RAG, tool calls

    chat_history = db.relationship("ChatHistory", backref="messages", lazy=True)

    def __repr__(self):
        return f"<ChatMessage {self.message_id} in Chat {self.chat_id}>"

class WebRoamingTask(db.Model):
    __tablename__ = "web_roaming_tasks"

    task_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=False)
    prompt = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(50), nullable=False, default="pending") # e.g., "pending", "running", "completed", "failed"
    result = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship("User", backref="web_roaming_tasks", lazy=True)

    def __repr__(self):
        return f"<WebRoamingTask {self.task_id} for User {self.user_id}>"

