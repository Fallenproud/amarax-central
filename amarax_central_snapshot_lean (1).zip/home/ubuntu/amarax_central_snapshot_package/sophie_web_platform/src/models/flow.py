from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.dialects.mysql import JSON # Retaining for compatibility, though design doc uses PostgreSQL/MySQL generally
from sqlalchemy.dialects.postgresql import JSONB # Preferred for PostgreSQL if that's the final choice
from .user import db # Assuming db is initialized in user.py or a shared models file
from datetime import datetime

class Flow(db.Model):
    __tablename__ = "agent_flows" # Matching design document table name

    flow_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=False) # Corrected ForeignKey
    flow_name = db.Column(db.String(255), nullable=False)
    flow_description = db.Column(db.Text, nullable=True)
    # Using JSONB for PostgreSQL or JSON for MySQL. For simplicity, stick to JSON as in original, but note design doc.
    flow_definition = db.Column(db.JSON, nullable=False) # Stores nodes, edges, positions etc.
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_public = db.Column(db.Boolean, default=False)

    user = db.relationship("User", backref=db.backref("flows", lazy=True))

    def __repr__(self):
        return f"<Flow {self.flow_name}>"

class AgentFlowExecution(db.Model):
    __tablename__ = "agent_flow_executions"

    execution_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    flow_id = db.Column(db.Integer, db.ForeignKey("agent_flows.flow_id"), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=False)
    start_time = db.Column(db.DateTime, default=datetime.utcnow)
    end_time = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(50), nullable=False, default="pending") # e.g., "pending", "running", "completed", "failed", "paused"
    input_data = db.Column(db.JSON, nullable=True)
    output_data = db.Column(db.JSON, nullable=True)
    current_step_id = db.Column(db.String(255), nullable=True)

    flow = db.relationship("Flow", backref=db.backref("executions", lazy=True))
    user = db.relationship("User", backref=db.backref("flow_executions", lazy=True))

    def __repr__(self):
        return f"<AgentFlowExecution {self.execution_id} for Flow {self.flow_id}>"

